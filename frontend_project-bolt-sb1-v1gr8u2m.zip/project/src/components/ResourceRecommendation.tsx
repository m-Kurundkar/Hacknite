import React from 'react';

interface ResourceRecommendationProps {
  recommendations: {
    type: string;
    description: string;
    impact: string;
  }[];
}

const ResourceRecommendation: React.FC<ResourceRecommendationProps> = ({ recommendations }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold mb-6">Resource Recommendations</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {recommendations.map((rec, index) => (
          <div key={index} className="border rounded-lg p-4">
            <h3 className="font-medium text-lg mb-2">{rec.type}</h3>
            <p className="text-gray-600 mb-3">{rec.description}</p>
            <div className="bg-green-50 p-3 rounded">
              <p className="text-sm text-green-700">
                <strong>Impact:</strong> {rec.impact}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ResourceRecommendation