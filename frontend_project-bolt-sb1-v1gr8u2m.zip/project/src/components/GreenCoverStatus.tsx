import React from 'react';
import { TreePine, Droplets } from 'lucide-react';

interface GreenCoverStatusProps {
  status: {
    current: string;
    recommendation: string;
    rainwaterPotential: string;
  };
}

const GreenCoverStatus: React.FC<GreenCoverStatusProps> = ({ status }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold mb-6">Green Cover Analysis</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <TreePine className="w-6 h-6 text-green-500" />
            <div>
              <h3 className="font-medium">Current Status</h3>
              <p className="text-gray-600">{status.current}</p>
            </div>
          </div>
          <div>
            <h3 className="font-medium">Recommendation</h3>
            <p className="text-gray-600">{status.recommendation}</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Droplets className="w-6 h-6 text-blue-400" />
          <div>
            <h3 className="font-medium">Rainwater Harvesting Potential</h3>
            <p className="text-gray-600">{status.rainwaterPotential}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GreenCoverStatus