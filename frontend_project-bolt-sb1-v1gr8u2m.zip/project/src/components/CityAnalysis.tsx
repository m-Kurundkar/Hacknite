import React from 'react';
import { Building, Sun, Wind, TreePine, Bird, Factory } from 'lucide-react';

interface CityAnalysisProps {
  data: {
    buildingDensity: string;
    solarPotential: string;
    windPotential: string;
    infrastructureScore: string;
    biodiversityIndex: string;
    greenSpaces: string;
    transportConnectivity: string;
    airQualityIndex: string;
  };
}

const CityAnalysis: React.FC<CityAnalysisProps> = ({ data }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold mb-6">City Infrastructure Analysis</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="flex items-start gap-4">
          <Building className="w-8 h-8 text-gray-600" />
          <div>
            <h3 className="font-medium">Building Density</h3>
            <p className="text-gray-600">{data.buildingDensity}</p>
            <p className="text-sm text-gray-500 mt-1">{data.infrastructureScore}</p>
          </div>
        </div>
        
        <div className="flex items-start gap-4">
          <Sun className="w-8 h-8 text-yellow-500" />
          <div>
            <h3 className="font-medium">Solar Potential</h3>
            <p className="text-gray-600">{data.solarPotential}</p>
          </div>
        </div>
        
        <div className="flex items-start gap-4">
          <Wind className="w-8 h-8 text-blue-500" />
          <div>
            <h3 className="font-medium">Wind Potential</h3>
            <p className="text-gray-600">{data.windPotential}</p>
          </div>
        </div>

        <div className="flex items-start gap-4">
          <Factory className="w-8 h-8 text-gray-500" />
          <div>
            <h3 className="font-medium">Transport Connectivity</h3>
            <p className="text-gray-600">{data.transportConnectivity}</p>
          </div>
        </div>

        <div className="flex items-start gap-4">
          <TreePine className="w-8 h-8 text-green-600" />
          <div>
            <h3 className="font-medium">Green Spaces</h3>
            <p className="text-gray-600">{data.greenSpaces}</p>
          </div>
        </div>

        <div className="flex items-start gap-4">
          <Bird className="w-8 h-8 text-amber-600" />
          <div>
            <h3 className="font-medium">Biodiversity Index</h3>
            <p className="text-gray-600">{data.biodiversityIndex}</p>
          </div>
        </div>

        <div className="col-span-2 bg-gray-50 rounded-lg p-4">
          <h3 className="font-medium text-gray-800 mb-2">Air Quality Status</h3>
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${getAQIColor(data.airQualityIndex)}`}></div>
            <p className="text-gray-600">{data.airQualityIndex}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function getAQIColor(aqi: string): string {
  const value = parseInt(aqi);
  if (value <= 50) return 'bg-green-500';
  if (value <= 100) return 'bg-yellow-500';
  if (value <= 150) return 'bg-orange-500';
  if (value <= 200) return 'bg-red-500';
  return 'bg-purple-500';
}

export default CityAnalysis;