import { get_land_type } from './osmData';

interface CityData {
  buildingDensity: string;
  solarPotential: string;
  windPotential: string;
  infrastructureScore: string;
  biodiversityIndex: string;
  greenSpaces: string;
  transportConnectivity: string;
  airQualityIndex: string;
}

interface Recommendations {
  type: string;
  description: string;
  impact: string;
}

interface GreenCoverStatus {
  current: string;
  recommendation: string;
  rainwaterPotential: string;
}

interface Suggestions {
  solar: string;
  wind: string;
  rainwater: string;
  greenCover: string;
}

export async function analyzeCity(city: string, coordinates: { lat: number; lon: number }) {
  const landUse = await get_land_type(coordinates.lat, coordinates.lon);

  const cityData: CityData = {
    buildingDensity: analyzeBuildingDensity(landUse),
    solarPotential: analyzeSolarPotential(city),
    windPotential: analyzeWindPotential(city),
    infrastructureScore: calculateInfrastructureScore(city),
    biodiversityIndex: getBiodiversityIndex(city),
    greenSpaces: analyzeGreenSpaces(city),
    transportConnectivity: getTransportConnectivity(city),
    airQualityIndex: getAirQualityIndex(city)
  };

  const recommendations: Recommendations[] = generateRecommendations(city, landUse);
  const greenCoverStatus: GreenCoverStatus = analyzeGreenCover(city, landUse);
  
  const suggestions: Suggestions = {
    solar: generateSolarSuggestions(city),
    wind: generateWindSuggestions(city),
    rainwater: generateRainwaterSuggestions(city),
    greenCover: generateGreenCoverSuggestions(city)
  };

  return {
    cityData,
    recommendations,
    greenCoverStatus,
    suggestions
  };
}

function analyzeBuildingDensity(landUse: string[]): string {
  const hasHighDensity = landUse.includes('Building') && landUse.includes('Commercial Area');
  return hasHighDensity ? 'High Density Urban Area' : 'Medium Density Mixed Use Area';
}

function analyzeSolarPotential(city: string): string {
  const solarPotentialMap = {
    'Delhi': 'High potential with 2500-2750 hours of sunshine per year',
    'Chennai': 'Very high potential with 2800-3000 hours of sunshine per year, coastal advantage',
    'Bengaluru': 'Good potential with 2400-2600 hours of sunshine per year'
  };
  return solarPotentialMap[city] || 'Moderate potential';
}

function analyzeWindPotential(city: string): string {
  const windPotentialMap = {
    'Delhi': 'Low to moderate potential, best for small-scale installations',
    'Chennai': 'High potential due to coastal location and monsoon winds',
    'Bengaluru': 'Moderate potential with seasonal variations'
  };
  return windPotentialMap[city] || 'Moderate potential';
}

function calculateInfrastructureScore(city: string): string {
  const scores = {
    'Delhi': 'Well-developed infrastructure with metro connectivity',
    'Chennai': 'Extensive public transport with metro and suburban rail',
    'Bengaluru': 'Rapidly developing infrastructure with tech focus'
  };
  return scores[city] || 'Developing infrastructure';
}

function getBiodiversityIndex(city: string): string {
  const biodiversityData = {
    'Delhi': 'Medium (7.2/10) - Ridge forest ecosystems, 200+ bird species',
    'Chennai': 'High (8.3/10) - Coastal wetlands, Pallikaranai marsh, marine ecosystems',
    'Bengaluru': 'Good (7.8/10) - Urban lakes, parks, 340+ bird species'
  };
  return biodiversityData[city] || 'Data not available';
}

function analyzeGreenSpaces(city: string): string {
  const greenSpaceData = {
    'Delhi': '20% coverage - Multiple forest reserves and urban parks',
    'Chennai': '15% coverage - Coastal wetlands and urban forests',
    'Bengaluru': '25% coverage - Urban forests and lake ecosystems'
  };
  return greenSpaceData[city] || 'Limited green space data';
}

function getTransportConnectivity(city: string): string {
  const transportData = {
    'Delhi': 'Excellent - Metro network, buses, and last-mile connectivity',
    'Chennai': 'Very Good - Metro, suburban trains, and MTC bus network',
    'Bengaluru': 'Good - Metro expansion, bus network, and tech corridors'
  };
  return transportData[city] || 'Basic transport infrastructure';
}

function getAirQualityIndex(city: string): string {
  const aqiData = {
    'Delhi': '98.6 - Poor air quality, needs improvement',
    'Chennai': '82.5 - Moderate air quality, coastal advantage',
    'Bengaluru': '81.0 - Relatively better air quality'
  };
  return aqiData[city] || 'AQI data not available';
}

function generateRecommendations(city: string, landUse: string[]): Recommendations[] {
  const recommendations: Recommendations[] = [];
  
  if (landUse.includes('Building')) {
    recommendations.push({
      type: 'Solar Installation',
      description: 'Rooftop solar installations on commercial and residential buildings',
      impact: 'Can offset 30-40% of building energy consumption'
    });
  }

  if (city === 'Chennai') {
    recommendations.push({
      type: 'Wind Energy',
      description: 'Small-scale wind turbines in coastal areas and high-rise buildings',
      impact: 'Potential to generate 15-20% of local energy needs'
    });
  }

  recommendations.push({
    type: 'Biodiversity Conservation',
    description: getBiodiversityRecommendation(city),
    impact: 'Enhance local ecosystem and urban wildlife corridors'
  });

  return recommendations;
}

function getBiodiversityRecommendation(city: string): string {
  const recommendations = {
    'Delhi': 'Expand Ridge forest buffer zones and create wildlife corridors',
    'Chennai': 'Protect coastal wetlands and enhance marine biodiversity',
    'Bengaluru': 'Restore lake ecosystems and connect urban forest patches'
  };
  return recommendations[city] || 'Implement urban biodiversity conservation measures';
}

function analyzeGreenCover(city: string, landUse: string[]): GreenCoverStatus {
  const hasParks = landUse.includes('Park');
  const hasForest = landUse.includes('Forest');

  const citySpecificStatus = {
    'Delhi': {
      current: 'Medium green cover with Ridge forest areas',
      recommendation: 'Increase urban forests and create biodiversity corridors',
      rainwaterPotential: 'High potential for rainwater harvesting in Ridge areas'
    },
    'Chennai': {
      current: 'Moderate green cover with coastal wetlands',
      recommendation: 'Protect wetlands and expand urban green spaces',
      rainwaterPotential: 'Very high potential with monsoon rainfall'
    },
    'Bengaluru': {
      current: 'Good green cover with urban lakes and parks',
      recommendation: 'Restore lake ecosystems and expand urban forests',
      rainwaterPotential: 'Excellent potential with year-round rainfall'
    }
  };

  return citySpecificStatus[city] || {
    current: hasParks || hasForest ? 'Moderate green cover with existing parks' : 'Limited green cover',
    recommendation: 'Increase urban forests and rooftop gardens',
    rainwaterPotential: 'High potential for rainwater harvesting systems'
  };
}

function generateSolarSuggestions(city: string): string {
  const suggestions = {
    'Delhi': 'Focus on large-scale rooftop solar with smart grid integration',
    'Chennai': 'Implement solar + storage systems with coastal durability',
    'Bengaluru': 'Deploy solar carports and building-integrated PV'
  };
  return suggestions[city] || 'Consider mixed solar installations';
}

function generateWindSuggestions(city: string): string {
  const suggestions = {
    'Delhi': 'Small-scale vertical axis wind turbines in urban areas',
    'Chennai': 'Coastal wind farms and building-integrated turbines',
    'Bengaluru': 'Building-mounted wind energy systems'
  };
  return suggestions[city] || 'Evaluate site-specific wind potential';
}

function generateRainwaterSuggestions(city: string): string {
  const suggestions = {
    'Delhi': 'Mandatory rainwater harvesting for all new constructions',
    'Chennai': 'Large-scale rainwater harvesting with flood mitigation',
    'Bengaluru': 'Integrated lake restoration and rainwater capture'
  };
  return suggestions[city] || 'Implement basic rainwater collection';
}

function generateGreenCoverSuggestions(city: string): string {
  const suggestions = {
    'Delhi': 'Create green corridors connecting existing parks',
    'Chennai': 'Develop coastal wetland preservation zones',
    'Bengaluru': 'Expand lake-front green spaces and urban forests'
  };
  return suggestions[city] || 'Increase urban green spaces';
}