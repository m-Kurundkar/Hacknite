interface LandUseResponse {
  elements: Array<{
    tags: Record<string, string>;
  }>;
}

export async function get_land_type(lat: number, lon: number): Promise<string[]> {
  const query = `
    [out:json];
    (
      node(around:500,${lat},${lon})["building"];
      way(around:500,${lat},${lon})["building"];
      way(around:500,${lat},${lon})["highway"];
      way(around:500,${lat},${lon})["landuse"];
      way(around:500,${lat},${lon})["natural"];
    );
    out body;
  `;

  try {
    const response = await fetch('https://overpass-api.de/api/interpreter', {
      method: 'POST',
      body: `data=${encodeURIComponent(query)}`,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch OSM data');
    }

    const data: LandUseResponse = await response.json();
    return categorize_land_use(data);
  } catch (error) {
    console.error('Error fetching OSM data:', error);
    return ['Unknown'];
  }
}

function categorize_land_use(data: LandUseResponse): string[] {
  const categories = {
    building: 'Building',
    highway: 'Road',
    landuse: {
      residential: 'Residential Area',
      commercial: 'Commercial Area',
      industrial: 'Industrial Zone',
      retail: 'Shopping Area',
      forest: 'Forest',
      farmland: 'Farmland',
      grass: 'Grassland',
      park: 'Park'
    },
    natural: {
      water: 'Water Body',
      forest: 'Forest',
      wood: 'Wooded Area'
    }
  };

  const landTypes = new Set<string>();

  if (data?.elements) {
    for (const element of data.elements) {
      const tags = element.tags || {};
      for (const [tag, value] of Object.entries(tags)) {
        if (tag in categories) {
          if (typeof categories[tag] === 'object') {
            landTypes.add(categories[tag][value] || value);
          } else {
            landTypes.add(categories[tag]);
          }
        }
      }
    }
  }

  return Array.from(landTypes).length ? Array.from(landTypes) : ['Unknown Land Use'];
}