import React, { useState } from 'react';
import { MapPin, Sun, Wind, Droplets, TreePine, Building, Leaf } from 'lucide-react';
import CityAnalysis from './components/CityAnalysis.tsx';
import ResourceRecommendation from './components/ResourceRecommendation.tsx';
import GreenCoverStatus from './components/GreenCoverStatus.tsx';
import { analyzeCity } from './utils/cityAnalysis';

function App() {
  const [selectedCity, setSelectedCity] = useState('');
  const [analysis, setAnalysis] = useState(null);

  const cities = {
    'Delhi': { lat: 28.6139, lon: 77.2090 },
    'Chennai': { lat: 13.0827, lon: 80.2707 },
    'Bengaluru': { lat: 12.9716, lon: 77.5946 }
  };

  const handleCitySelect = async (city: string) => {
    setSelectedCity(city);
    const result = await analyzeCity(city, cities[city]);
    setAnalysis(result);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-green-600 to-teal-600 text-white">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="container mx-auto px-4 py-16 relative">
          <div className="flex items-center justify-between">
            <div className="max-w-2xl">
              <h1 className="text-6xl font-bold mb-4 tracking-tight">
                SUSTAINEWABLE
              </h1>
              <div className="h-1 w-24 bg-green-300 mb-6"></div>
              <p className="text-xl text-green-50 mb-8">
                Empowering cities with sustainable solutions through advanced renewable resource analysis
              </p>
            </div>
            <Leaf className="w-32 h-32 text-green-200 opacity-50" />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* City Selection */}
        <div className="mb-12">
          <h2 className="text-2xl font-semibold text-gray-800 mb-6">Select a City for Analysis</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {Object.keys(cities).map((city) => (
              <button
                key={city}
                onClick={() => handleCitySelect(city)}
                className={`
                  p-6 rounded-xl shadow-lg transition-all duration-300 transform hover:scale-105
                  ${
                    selectedCity === city
                      ? 'bg-gradient-to-r from-green-500 to-teal-500 text-white'
                      : 'bg-white hover:bg-green-50'
                  }
                `}
              >
                <div className="flex items-center justify-center gap-3">
                  <MapPin className={`w-6 h-6 ${selectedCity === city ? 'text-white' : 'text-green-600'}`} />
                  <span className="text-lg font-semibold">{city}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {analysis && (
          <div className="space-y-8 animate-fadeIn">
            <CityAnalysis data={analysis.cityData} />
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <ResourceRecommendation recommendations={analysis.recommendations} />
              <GreenCoverStatus status={analysis.greenCoverStatus} />
            </div>
            
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-semibold mb-6 text-gray-800">Interactive Suggestions</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="flex items-start gap-4 p-4 bg-yellow-50 rounded-lg">
                    <Sun className="w-8 h-8 text-yellow-500" />
                    <div>
                      <h4 className="font-semibold text-gray-800">Solar Potential</h4>
                      <p className="text-gray-600 mt-2">{analysis.suggestions.solar}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-lg">
                    <Wind className="w-8 h-8 text-blue-500" />
                    <div>
                      <h4 className="font-semibold text-gray-800">Wind Energy</h4>
                      <p className="text-gray-600 mt-2">{analysis.suggestions.wind}</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-6">
                  <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-lg">
                    <Droplets className="w-8 h-8 text-blue-400" />
                    <div>
                      <h4 className="font-semibold text-gray-800">Rainwater Harvesting</h4>
                      <p className="text-gray-600 mt-2">{analysis.suggestions.rainwater}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 p-4 bg-green-50 rounded-lg">
                    <TreePine className="w-8 h-8 text-green-500" />
                    <div>
                      <h4 className="font-semibold text-gray-800">Green Cover</h4>
                      <p className="text-gray-600 mt-2">{analysis.suggestions.greenCover}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;